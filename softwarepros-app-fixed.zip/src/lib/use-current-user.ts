"use client";

import { useEffect, useState } from "react";

type CurrentUser = { id: string; email: string } | null;

/**
 * Client-side read of who (if anyone) is signed in, for nav chrome that
 * needs to show a Sign In link vs. an account menu. `undefined` while the
 * first request is in flight, so callers can render nothing rather than
 * flash the wrong state.
 */
export function useCurrentUser(): CurrentUser | undefined {
  const [user, setUser] = useState<CurrentUser | undefined>(undefined);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me")
      .then((res) => (res.ok ? res.json() : { user: null }))
      .then((body: { user: CurrentUser }) => {
        if (!cancelled) setUser(body.user ?? null);
      })
      .catch(() => {
        if (!cancelled) setUser(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return user;
}
