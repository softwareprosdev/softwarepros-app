import { z } from "zod";

/**
 * Converts a Zod schema into a JSON Schema compatible with Groq's strict
 * structured-output mode. Strict mode requires every object — including
 * nested ones — to set `additionalProperties: false` and list every one of
 * its keys under `required`. `z.toJSONSchema()` only adds those when the
 * Zod schema itself was built with `.strict()`, so this walks the emitted
 * JSON Schema and enforces both rules everywhere an object appears.
 */
export function toStrictJsonSchema(schema: z.ZodType) {
  const json = z.toJSONSchema(schema, { target: "draft-7" }) as Record<
    string,
    unknown
  >;
  enforceStrict(json);
  return json;
}

function enforceStrict(node: unknown): void {
  if (!node || typeof node !== "object") return;

  if (Array.isArray(node)) {
    for (const item of node) enforceStrict(item);
    return;
  }

  const obj = node as Record<string, unknown>;
  if (
    obj.type === "object" &&
    obj.properties &&
    typeof obj.properties === "object"
  ) {
    obj.additionalProperties = false;
    obj.required = Object.keys(obj.properties as Record<string, unknown>);
  }

  for (const value of Object.values(obj)) {
    enforceStrict(value);
  }
}
