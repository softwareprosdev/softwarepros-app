import "server-only";
import { groq, MODEL } from "@/lib/ai/client";
import { toStrictJsonSchema } from "@/lib/ai/json-schema";
import {
  ANALYSIS_SYSTEM_PROMPT,
  SUMMARY_SYSTEM_PROMPT,
  conversationTranscript,
} from "@/lib/ai/prompts";
import { AnalysisSchema, SummarySchema, type Analysis, type Summary } from "@/lib/ai/schemas";

type Turn = { role: string; content: string };

/**
 * Re-derives the live analysis panel from the whole conversation. Runs after
 * each assistant turn; failures are non-fatal (the panel just keeps its
 * previous values) so a schema hiccup never breaks the chat.
 */
export async function extractAnalysis(turns: Turn[]): Promise<Analysis | null> {
  try {
    const completion = await groq.chat.completions.create({
      model: MODEL,
      max_completion_tokens: 4096,
      messages: [
        { role: "system", content: ANALYSIS_SYSTEM_PROMPT },
        {
          role: "user",
          content: `Analyse this discovery conversation and report the current state of understanding.\n\n<conversation>\n${conversationTranscript(turns)}\n</conversation>`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "analysis",
          strict: true,
          schema: toStrictJsonSchema(AnalysisSchema),
        },
      },
    });

    const raw = completion.choices[0]?.message?.content;
    if (!raw) return null;
    return AnalysisSchema.parse(JSON.parse(raw));
  } catch (error) {
    console.error("[analysis] extraction failed", error);
    return null;
  }
}

/** Generates the full project summary document from a conversation. */
export async function generateSummary(turns: Turn[]): Promise<Summary> {
  const completion = await groq.chat.completions.create({
    model: MODEL,
    max_completion_tokens: 16000,
    messages: [
      { role: "system", content: SUMMARY_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Produce the project summary document for this discovery conversation.\n\n<conversation>\n${conversationTranscript(turns)}\n</conversation>`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "summary",
        strict: true,
        schema: toStrictJsonSchema(SummarySchema),
      },
    },
  });

  const raw = completion.choices[0]?.message?.content;
  if (!raw) {
    throw new Error("The AI Architect could not produce a valid summary.");
  }

  try {
    return SummarySchema.parse(JSON.parse(raw));
  } catch (error) {
    console.error("[analysis] summary failed schema validation", error);
    throw new Error("The AI Architect could not produce a valid summary.");
  }
}
