import "server-only";

const MAX_CHARS = 200_000;

/**
 * Best-effort text extraction for uploaded PDFs. The free model behind the
 * AI Architect can't read PDF bytes natively the way Claude could, so a PDF
 * attachment gets its text pulled out here and handed over as plain text
 * instead. Returns null (never throws) when the PDF has no extractable text
 * — a scanned/image-only PDF, for example — so the caller can fall back to
 * telling the model plainly that it couldn't read the file.
 */
export async function extractPdfText(base64: string): Promise<string | null> {
  try {
    const { PDFParse } = await import("pdf-parse");
    const buffer = Buffer.from(base64, "base64");
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText();
      const text = result.text?.trim();
      if (!text) return null;
      return text.slice(0, MAX_CHARS);
    } finally {
      await parser.destroy();
    }
  } catch (error) {
    console.error("[pdf] extraction failed", error);
    return null;
  }
}
