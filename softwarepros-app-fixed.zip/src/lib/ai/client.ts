import Groq from "groq-sdk";

/**
 * Shared Groq client. The SDK resolves credentials from GROQ_API_KEY
 * automatically. Groq is used because it offers a generous free tier
 * for the models below, with an OpenAI-compatible API.
 */
export const groq = new Groq();

/** Primary text/reasoning model used for the AI Architect chat, analysis and summary. */
export const MODEL = "openai/gpt-oss-120b";

/** Vision-capable model, used only for turns that include an image attachment. */
export const VISION_MODEL = "qwen/qwen3.8-27b";

export function hasGroqCredentials() {
  return Boolean(process.env.GROQ_API_KEY);
}
