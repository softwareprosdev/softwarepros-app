import "server-only";
import { cookies } from "next/headers";
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { prisma } from "@/lib/prisma";
import { publicId } from "@/lib/ids";
import { AUTH_COOKIE_NAME } from "@/lib/cookie-names";

const scrypt = promisify(scryptCallback);

const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 days
const KEY_LENGTH = 64;

/**
 * Hashes a password with scrypt and a random per-password salt. Stored as
 * `salt:hash`, both hex, so verification never needs a second lookup.
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, KEY_LENGTH)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

/** Constant-time password check against a `hashPassword` value. */
export async function verifyPassword(
  password: string,
  stored: string,
): Promise<boolean> {
  const [salt, hashHex] = stored.split(":");
  if (!salt || !hashHex) return false;

  const derived = (await scrypt(password, salt, KEY_LENGTH)) as Buffer;
  const expected = Buffer.from(hashHex, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

/**
 * Starts a signed-in session: creates a `UserSession` row and sets the
 * httpOnly bearer-token cookie. Only valid inside a Route Handler (Server
 * Components cannot set cookies).
 */
export async function createUserSession(userId: string): Promise<void> {
  const token = publicId(32);
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE_SECONDS * 1000);
  await prisma.userSession.create({ data: { token, userId, expiresAt } });

  const store = await cookies();
  store.set(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
}

/**
 * Resolves the caller's signed-in account from the session cookie, or null
 * for a signed-out visitor. This — not `readOwnerToken()` — is the check
 * every discovery-session read or write must pass before touching another
 * user's conversation.
 */
export async function getCurrentUser(): Promise<{
  id: string;
  email: string;
} | null> {
  const store = await cookies();
  const token = store.get(AUTH_COOKIE_NAME)?.value;
  if (!token) return null;

  const session = await prisma.userSession.findUnique({
    where: { token },
    select: {
      expiresAt: true,
      user: { select: { id: true, email: true } },
    },
  });
  if (!session || session.expiresAt < new Date()) return null;

  return session.user;
}

/** Ends the caller's signed-in session and clears the cookie. */
export async function destroyCurrentSession(): Promise<void> {
  const store = await cookies();
  const token = store.get(AUTH_COOKIE_NAME)?.value;
  store.delete(AUTH_COOKIE_NAME);

  if (token) {
    await prisma.userSession.deleteMany({ where: { token } }).catch(() => {
      // Best-effort cleanup — the cookie is already gone either way.
    });
  }
}
