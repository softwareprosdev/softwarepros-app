import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { pageMetadata } from "@/lib/metadata";
import { getCurrentUser } from "@/lib/user-auth";
import { Wordmark } from "@/components/SiteNav";
import { AuthForm } from "@/components/auth/AuthForm";

export const metadata: Metadata = pageMetadata({
  path: "/signup",
  title: "Create Account",
  description: "Create a SoftwarePros account to start a private AI Discovery Center session.",
});

/** Safe internal redirect target only — never forward a caller-supplied
 * absolute or protocol-relative URL off this site. */
function safeCallbackUrl(value: string | string[] | undefined): string {
  const raw = Array.isArray(value) ? value[0] : value;
  if (raw && raw.startsWith("/") && !raw.startsWith("//")) return raw;
  return "/discovery";
}

export default async function SignupPage({
  searchParams,
}: PageProps<"/signup">) {
  const params = await searchParams;
  const callbackUrl = safeCallbackUrl(params.callbackUrl);

  const user = await getCurrentUser();
  if (user) redirect(callbackUrl);

  return (
    <div className="min-h-dvh flex flex-col">
      <nav className="h-14 shrink-0 flex items-center px-6 border-b border-white/5">
        <Wordmark className="text-lg" />
      </nav>
      <main className="flex-1 flex flex-col items-center justify-center px-6">
        <div className="w-full max-w-sm mb-8 text-center">
          <h1 className="text-2xl font-bold text-white mb-2">
            Create your account
          </h1>
          <p className="text-sm text-gray-400">
            Sign in is required to talk to the AI Architect, so your project
            details and conversation history stay private to you.
          </p>
        </div>
        <AuthForm mode="signup" callbackUrl={callbackUrl} />
      </main>
    </div>
  );
}
