import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/user-auth";
import { DiscoveryBootstrap } from "@/components/discovery/DiscoveryBootstrap";

export const metadata: Metadata = {
  title: "AI Discovery Center",
  description:
    "Describe your business problem and the SoftwarePros AI Architect will turn it into an engineer-ready system definition.",
  // Every GET here mints a session and forwards; there is nothing to index.
  robots: { index: false, follow: false },
};

/**
 * `/discovery` has no UI of its own — it mints a session and forwards to it so
 * every conversation gets a stable, shareable URL. Session creation goes
 * through the API route rather than happening here because it needs to set the
 * owner cookie, which a Server Component cannot do.
 *
 * Signing in is required before that happens: every session is now owned by
 * an account, not just a browser cookie, so a visitor who isn't signed in is
 * sent to sign in first and lands back here afterward.
 */
export default async function DiscoveryIndex({
  searchParams,
}: PageProps<"/discovery">) {
  const { mode, q } = await searchParams;

  const user = await getCurrentUser();
  if (!user) {
    const targetParams = new URLSearchParams();
    if (mode === "upload") targetParams.set("mode", "upload");
    if (typeof q === "string" && q) targetParams.set("q", q);
    const query = targetParams.toString();
    const target = `/discovery${query ? `?${query}` : ""}`;
    redirect(`/login?callbackUrl=${encodeURIComponent(target)}`);
  }
  // `q` is the SearchAction entry point declared in the site's structured
  // data; trimmed and length-capped here so a crafted link cannot post a
  // 100 KB first message. The API validates it again regardless.
  const query = typeof q === "string" ? q.trim().slice(0, 2000) : undefined;

  return (
    <DiscoveryBootstrap
      mode={mode === "upload" ? "upload" : undefined}
      query={query || undefined}
    />
  );
}
