import { z } from "zod";
import { groq, MODEL, VISION_MODEL, hasGroqCredentials } from "@/lib/ai/client";
import { ARCHITECT_SYSTEM_PROMPT } from "@/lib/ai/prompts";
import { extractAnalysis } from "@/lib/ai/analysis";
import { extractPdfText } from "@/lib/ai/pdf";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/user-auth";
import { clientKey, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const maxDuration = 120;

const ChatRequest = z.object({
  sessionId: z.string().min(1),
  message: z.string().trim().min(1).max(20_000).optional(),
  attachmentIds: z.array(z.string()).max(10).optional(),
  /**
   * Answer the session's existing trailing client message instead of adding a
   * new one. Used when a session arrives pre-seeded (e.g. from the voice modal)
   * so the opening message isn't persisted twice.
   */
  resume: z.boolean().optional(),
});

type StreamEvent =
  | { type: "text"; text: string }
  | { type: "analysis"; analysis: unknown }
  | { type: "done"; messageId: string }
  | { type: "error"; error: string };

type TextPart = { type: "text"; text: string };
type ImagePart = { type: "image_url"; image_url: { url: string } };

type ChatMessage =
  | { role: "system" | "assistant"; content: string }
  | { role: "user"; content: string | Array<TextPart | ImagePart> };

function encodeEvent(event: StreamEvent) {
  // Newline-delimited JSON: trivially parseable from the client without an
  // SSE library, and each event is self-contained.
  return new TextEncoder().encode(`${JSON.stringify(event)}\n`);
}

export async function POST(request: Request) {
  // Every call here spends model tokens, so it's rate limited before anything else.
  const limit = rateLimit(clientKey(request, "chat"), {
    limit: 20,
    windowMs: 60_000,
  });
  if (!limit.ok) {
    return tooManyRequests(
      limit,
      "You're sending messages faster than the architect can answer. Give it a moment.",
    );
  }

  const parsed = ChatRequest.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  if (!hasGroqCredentials()) {
    return Response.json(
      {
        error:
          "The AI Architect is not configured. Set GROQ_API_KEY in your environment.",
      },
      { status: 503 },
    );
  }

  const user = await getCurrentUser();
  if (!user) {
    return Response.json(
      { error: "Sign in to continue this conversation." },
      { status: 401 },
    );
  }

  const { sessionId, attachmentIds, resume } = parsed.data;

  const session = await prisma.discoverySession.findUnique({
    where: { publicId: sessionId },
    include: { messages: { orderBy: { createdAt: "asc" } } },
  });
  // Same 404 whether the session doesn't exist or belongs to someone else.
  // This is the check that actually keeps one visitor's conversation history
  // out of another visitor's hands — the publicId alone used to be treated
  // as sufficient, and it isn't: it only proves you have a link, not that
  // it's yours.
  if (!session || session.userId !== user.id) {
    return Response.json({ error: "Session not found" }, { status: 404 });
  }

  // In resume mode the client message already exists; otherwise persist it.
  const trailing = session.messages.at(-1);
  let message: string;
  let priorMessages = session.messages;

  if (resume) {
    if (!trailing || trailing.role !== "USER") {
      return Response.json(
        { error: "Nothing to resume — the last turn was not a client message." },
        { status: 409 },
      );
    }
    message = trailing.content;
    priorMessages = session.messages.slice(0, -1);
  } else {
    if (!parsed.data.message) {
      return Response.json({ error: "A message is required." }, { status: 400 });
    }
    message = parsed.data.message;
  }

  const attachments = attachmentIds?.length
    ? await prisma.attachment.findMany({
        where: { id: { in: attachmentIds }, sessionId: session.id },
      })
    : [];

  if (!resume) {
    const userMessage = await prisma.message.create({
      data: { sessionId: session.id, role: "USER", content: message },
    });
    if (attachments.length) {
      await prisma.attachment.updateMany({
        where: { id: { in: attachments.map((a) => a.id) } },
        data: { messageId: userMessage.id },
      });
    }
  }

  // Prior turns as plain text; the new turn may also carry attachments.
  const history: ChatMessage[] = priorMessages.map((m) => ({
    role: m.role === "USER" ? "user" : "assistant",
    content: m.content,
  }));

  const currentContent: Array<TextPart | ImagePart> = [];
  let hasImage = false;

  for (const attachment of attachments) {
    if (attachment.kind === "IMAGE") {
      hasImage = true;
      const mimeType = attachment.mimeType || "image/png";
      currentContent.push({
        type: "image_url",
        image_url: { url: `data:${mimeType};base64,${attachment.content}` },
      });
    } else if (attachment.mimeType === "application/pdf") {
      // The free model can't read PDF bytes natively the way Claude could,
      // so the text is pulled out server-side and handed over as a
      // <document> block instead — same shape as a plain-text upload.
      const text = await extractPdfText(attachment.content);
      currentContent.push({
        type: "text",
        text: text
          ? `<document filename="${attachment.filename}">\n${text}\n</document>`
          : `<document filename="${attachment.filename}">\n[This PDF could not be read automatically — it may be a scanned or image-only document. Ask the client to paste the key details as text.]\n</document>`,
      });
    } else {
      currentContent.push({
        type: "text",
        text: `<document filename="${attachment.filename}">\n${attachment.content}\n</document>`,
      });
    }
  }
  currentContent.push({ type: "text", text: message });

  const messages: ChatMessage[] = [
    { role: "system", content: ARCHITECT_SYSTEM_PROMPT },
    ...history,
    { role: "user", content: currentContent },
  ];

  // Vision-capable turns need the vision model — the primary text model
  // can't see image content parts at all.
  const model = hasImage ? VISION_MODEL : MODEL;

  const stream = new ReadableStream({
    async start(controller) {
      let full = "";
      try {
        const aiStream = await groq.chat.completions.create({
          model,
          max_completion_tokens: 4096,
          messages,
          stream: true,
        });

        let finishReason: string | null = null;
        for await (const chunk of aiStream) {
          const choice = chunk.choices[0];
          const delta = choice?.delta?.content;
          if (delta) {
            full += delta;
            controller.enqueue(encodeEvent({ type: "text", text: delta }));
          }
          if (choice?.finish_reason) {
            finishReason = choice.finish_reason;
          }
        }

        if (finishReason === "content_filter" || !full.trim()) {
          const notice =
            "I can't help with that request. If you think this is a mistake, describe the business problem instead and I'll pick it up from there.";
          controller.enqueue(encodeEvent({ type: "text", text: notice }));
          full = notice;
        }

        const assistantMessage = await prisma.message.create({
          data: {
            sessionId: session.id,
            role: "ASSISTANT",
            content: full,
          },
        });

        // Refresh the live-analysis panel from the full conversation.
        const turns = [
          ...priorMessages.map((m) => ({ role: m.role, content: m.content })),
          { role: "USER", content: message },
          { role: "ASSISTANT", content: full },
        ];
        const analysis = await extractAnalysis(turns);

        if (analysis) {
          await prisma.discoverySession.update({
            where: { id: session.id },
            data: {
              title: analysis.title || session.title,
              industry: analysis.industry || null,
              scale: analysis.scale || null,
              complexity: analysis.complexity || null,
              currentState: analysis.currentState || null,
              clarityScore: clamp(analysis.clarityScore, 0, 100),
              requirementsFound: Math.max(0, analysis.requirementsFound),
              requirementsTarget: Math.max(1, analysis.requirementsTarget),
              recommendedPlatform: analysis.recommendedPlatform || null,
              modules: analysis.modules,
              unclearModules: analysis.unclearModules,
              clarifications: analysis.clarifications,
              suggestions: analysis.suggestions,
            },
          });
          controller.enqueue(encodeEvent({ type: "analysis", analysis }));
        }

        controller.enqueue(
          encodeEvent({ type: "done", messageId: assistantMessage.id }),
        );
      } catch (error) {
        console.error("[chat] stream failed", error);
        controller.enqueue(
          encodeEvent({
            type: "error",
            error:
              "The AI Architect hit an error mid-response. Your message was saved — try again.",
          }),
        );
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Math.round(value)));
}
