import { getCurrentUser } from "@/lib/user-auth";

/** Lets client components (nav, voice modal) know whether anyone is signed in. */
export async function GET() {
  const user = await getCurrentUser();
  return Response.json(
    { user },
    { headers: { "Cache-Control": "private, no-store" } },
  );
}
