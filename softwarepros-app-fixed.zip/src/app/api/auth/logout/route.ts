import { destroyCurrentSession } from "@/lib/user-auth";

export async function POST() {
  await destroyCurrentSession();
  return Response.json({ ok: true });
}
