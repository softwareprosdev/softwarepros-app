import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { hashPassword, createUserSession } from "@/lib/user-auth";
import { clientKey, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { logDbFailure } from "@/lib/db-errors";

const RegisterRequest = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(8).max(200),
});

/** Creates an account and signs the caller in. Required before the AI
 * Discovery Center will start or reopen a conversation — see /api/chat. */
export async function POST(request: Request) {
  const limit = rateLimit(clientKey(request, "auth-register"), {
    limit: 10,
    windowMs: 60_000,
  });
  if (!limit.ok) {
    return tooManyRequests(limit, "Too many sign-up attempts. Try again shortly.");
  }

  const parsed = RegisterRequest.safeParse(
    await request.json().catch(() => null),
  );
  if (!parsed.success) {
    return Response.json(
      { error: "Enter a valid email and a password of at least 8 characters." },
      { status: 400 },
    );
  }

  const { email, password } = parsed.data;

  try {
    const existing = await prisma.user.findUnique({
      where: { email },
      select: { id: true },
    });
    if (existing) {
      return Response.json(
        { error: "An account with that email already exists." },
        { status: 409 },
      );
    }

    const passwordHash = await hashPassword(password);
    const user = await prisma.user.create({
      data: { email, passwordHash },
      select: { id: true },
    });
    await createUserSession(user.id);

    return Response.json({ ok: true }, { status: 201 });
  } catch (error) {
    const failure = logDbFailure("registerUser", error);
    return Response.json(
      {
        error: "Could not create your account. This is on our side, not yours.",
        code: failure.code,
      },
      { status: 503 },
    );
  }
}
