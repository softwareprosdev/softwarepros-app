import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyPassword, createUserSession } from "@/lib/user-auth";
import { clientKey, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { logDbFailure } from "@/lib/db-errors";

const LoginRequest = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(1).max(200),
});

export async function POST(request: Request) {
  // A password-guessing endpoint gets a tighter budget than everything else
  // in this app.
  const limit = rateLimit(clientKey(request, "auth-login"), {
    limit: 10,
    windowMs: 60_000,
  });
  if (!limit.ok) {
    return tooManyRequests(limit, "Too many sign-in attempts. Try again shortly.");
  }

  const parsed = LoginRequest.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return Response.json(
      { error: "Enter your email and password." },
      { status: 400 },
    );
  }

  const { email, password } = parsed.data;

  try {
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, passwordHash: true },
    });

    // Same message either way — a distinct one would tell a caller which
    // emails have accounts.
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return Response.json(
        { error: "Incorrect email or password." },
        { status: 401 },
      );
    }

    await createUserSession(user.id);
    return Response.json({ ok: true });
  } catch (error) {
    const failure = logDbFailure("loginUser", error);
    return Response.json(
      {
        error: "Could not sign you in. This is on our side, not yours.",
        code: failure.code,
      },
      { status: 503 },
    );
  }
}
