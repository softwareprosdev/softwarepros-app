"use client";

import Link from "next/link";
import { useId, useState } from "react";
import { useRouter } from "next/navigation";
import { Icon } from "@/components/Icon";

const FIELD =
  "w-full bg-white/[0.03] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-600 outline-none focus:border-primary/60 transition-colors";
const LABEL =
  "block text-[10px] font-bold tracking-widest uppercase text-gray-500 mb-2";

export function AuthForm({
  mode,
  callbackUrl,
}: {
  mode: "login" | "signup";
  callbackUrl: string;
}) {
  const id = useId();
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "sending" | "error">("idle");
  const [error, setError] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "sending") return;

    const form = event.currentTarget;
    const data = new FormData(form);
    const email = String(data.get("email") ?? "").trim();
    const password = String(data.get("password") ?? "");

    setStatus("sending");
    setError("");

    try {
      const res = await fetch(
        mode === "login" ? "/api/auth/login" : "/api/auth/register",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        },
      );

      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(
          typeof body.error === "string" ? body.error : "Something went wrong.",
        );
      }

      router.replace(callbackUrl);
      router.refresh();
    } catch (err) {
      setStatus("error");
      setError(
        err instanceof Error && err.message
          ? err.message
          : "Something went wrong. Please try again.",
      );
    }
  }

  const isLogin = mode === "login";

  return (
    <form onSubmit={onSubmit} className="w-full max-w-sm">
      <div className="mb-6">
        <label htmlFor={`${id}-email`} className={LABEL}>
          Email
        </label>
        <input
          id={`${id}-email`}
          name="email"
          type="email"
          required
          autoComplete="email"
          placeholder="you@company.com"
          className={FIELD}
        />
      </div>

      <div className="mb-2">
        <label htmlFor={`${id}-password`} className={LABEL}>
          Password
        </label>
        <input
          id={`${id}-password`}
          name="password"
          type="password"
          required
          minLength={isLogin ? undefined : 8}
          autoComplete={isLogin ? "current-password" : "new-password"}
          placeholder={isLogin ? "Your password" : "At least 8 characters"}
          className={FIELD}
        />
      </div>

      {error && (
        <p className="text-xs text-red-400 mt-3" role="alert">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "sending"}
        className="mt-6 w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full text-sm font-semibold text-white hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {status === "sending" && <Icon name="spinner" spin />}
        {isLogin ? "Sign In" : "Create Account"}
      </button>

      <p className="text-xs text-gray-500 mt-6 text-center">
        {isLogin ? (
          <>
            Don&apos;t have an account?{" "}
            <Link
              href={`/signup?callbackUrl=${encodeURIComponent(callbackUrl)}`}
              className="text-primary hover:underline"
            >
              Create one
            </Link>
          </>
        ) : (
          <>
            Already have an account?{" "}
            <Link
              href={`/login?callbackUrl=${encodeURIComponent(callbackUrl)}`}
              className="text-primary hover:underline"
            >
              Sign in
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
